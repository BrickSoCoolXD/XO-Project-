﻿using System;

namespace Bot;

class Program
{
    public static void Main(string[]args)
    {
        Comagain:
        Console.WriteLine("Please select the mode");
        Console.WriteLine("1) Single Player || 2) TwoPlayer");

        int mode = Int16.Parse(Console.ReadLine());

        switch(mode) {
            case 1:
                Console.WriteLine("User has select SinglePlayer Mode. ");
                Console.Clear();
                SinglePlayer();
                break;
            case 2:
                Console.WriteLine("User has select TwoPlayer Mode!");
                Console.Clear();
                TwoPlayer();
                break;
            default:
                goto Comagain;
        }
    }

    public static void SinglePlayer()
    {
        char player1Symbol = 'X';
        char player2Symbol = 'O';
        int turn = 0;
        char[] gameBoard = new char[9] { '-', '-', '-', '-', '-', '-', '-', '-', '-' };
        string winner = string.Empty;


        Console.ForegroundColor = ConsoleColor.Green;

        Console.WriteLine("Welcome to my simple tic tac toe game. You can place a symbol on the board by selecting its place on the board (0-8)\n");
        Console.WriteLine("Please Note: Your symbol is X , the computer plays with O.");
        Console.WriteLine("Press Enter to start playing!");
        Console.ReadKey();

        while (true)
        {
            Console.Clear();
            Board(gameBoard);

            int checkWinner = gameWonDicider(gameBoard);


            switch (checkWinner)
            {
                case 1:
                    Console.WriteLine("Player 1 wins!");
                    return;

                case 2:
                    Console.WriteLine("Player 2 wins!");
                    return;
                case 3:
                    Console.WriteLine("Draw!");
                    return;
                default:
                    break;
            }
            if (turn % 2 == 0)
            {
                gameBoard = playerTurn(player1Symbol, gameBoard);
            }
            else
            {
                gameBoard = computerTurn(player2Symbol, gameBoard);
            }
            turn++;

    }
}
    public static void TwoPlayer()
    {
        //

        char player1Symbol = 'X';
        char player2Symbol = 'O';
        int turn = 0;
        char[] gameBoard = new char[9] { '-', '-', '-', '-', '-', '-', '-', '-', '-' };
        string winner = string.Empty;

        Console.ForegroundColor = ConsoleColor.Green;

        Console.WriteLine("Welcome to my simple tic tac toe game. You can place a symbol on the board by selecting its place on the board (0-8)\n");

        while (true)
        {
            Board(gameBoard);

            int checkWinner = gameWonDicider(gameBoard);


            switch (checkWinner)
            {
                case 1:
                    Console.WriteLine("Player 1 wins!");
                    return;

                case 2:
                    Console.WriteLine("Player 2 wins!");
                    return;
                case 3:
                    Console.WriteLine("Draw!");
                    return;
                default:
                    break;
            }
            if (turn % 2 == 0)
            {
                gameBoard = playerTurn(player1Symbol, gameBoard);
            }
            else
            {
                gameBoard = playerTurn(player2Symbol, gameBoard);
            }
            turn++;

        }
    }


        public static void Board(char[] gameBoard)
    {

        //board body
        string outPutBoard = $"| {gameBoard[0]} | {gameBoard[1]} | {gameBoard[2]} |\n| {gameBoard[3]} | {gameBoard[4]} | {gameBoard[5]} |\n| {gameBoard[6]} | {gameBoard[7]} | {gameBoard[8]} | \n";
        Console.WriteLine(outPutBoard);
    }

    private static bool verifyLegalTurn(int place, char[] gameBoard)
    {
        bool isLegal = false;
        //Make sure that the player doesn't input anything that is outside of the board.
        if (place >= gameBoard.Length || place < 0)
        {
            Console.WriteLine("THAT SPOT DOES NOT EXIST... :)");
            return isLegal;
        }
        //Empty places in the board are marked as '-'
        if (gameBoard[place] == '-') { isLegal = true; }
        else
        {
            Console.WriteLine("ILLEGAL MOVE!");
        }
        return isLegal;
    }

    public static char[] playerTurn(char playerSymbol, char[] gameBoard)
    {
        while (true)
        {
            int place = int.Parse(Console.ReadLine());
            if (verifyLegalTurn(place, gameBoard))
            {
                gameBoard[place] = playerSymbol;
                break;
            }
        }
        return gameBoard;
    }

    private static char[] computerTurn(char playerSymbol, char[] gameBoard)
    {
        int firstFreeIndex = 0;
        int tries = 0;

        //Find first free index

        for (int i = 0; i < gameBoard.Length; i++)
        {
            if (gameBoard[i] == '-') { firstFreeIndex = i; break; }
        }

        //Randomly pick a spot, if the spot is already filled with X or O, try a new spot.
        while (tries < 2)
        {
            Random randomIndexPicker = new Random();
            int cpuChoice = randomIndexPicker.Next(0, gameBoard.Length - 1);
            if (gameBoard[cpuChoice] == '-') { gameBoard[cpuChoice] = playerSymbol; return gameBoard; }
            else { tries++; }
        }

        gameBoard[firstFreeIndex] = playerSymbol;

        return gameBoard;
    }


    //Function check if someone has 3 connected symblos, meeting the win
    public static bool diagonalCheck(char[] gameBoard,int target)
    {
        bool detectWin = false;
        int sum1Diag = gameBoard[0] + gameBoard[4] + gameBoard[8];
        int sum2Diag = gameBoard[2] + gameBoard[4] + gameBoard[6];

        if(sum1Diag == target || sum2Diag == target) { detectWin = true; }
        return detectWin;
    }

    public static bool colCheck(char[] gameBoard, int target)
    {
        bool detectedWin = false;
        int sum1Row = gameBoard[0] + gameBoard[3] + gameBoard[6];
        int sum2Row = gameBoard[1] + gameBoard[4] + gameBoard[7];
        int sum3Row = gameBoard[2] + gameBoard[5] + gameBoard[8];

        if (sum1Row == target || sum2Row == target || sum3Row == target) { detectedWin = true; }
        return detectedWin;
    }

    public static bool rowCheck(char[] gameBoard, int target)
    {
        bool detectedWin = false;
        int sum1Row = gameBoard[0] + gameBoard[3] + gameBoard[6];
        int sum2Row = gameBoard[1] + gameBoard[4] + gameBoard[7];
        int sum3Row = gameBoard[2] + gameBoard[5] + gameBoard[8];

        if (sum1Row == target || sum2Row == target || sum3Row == target) { detectedWin = true; }
        return detectedWin;
    }

    public static int gameWonDicider(char[] gameBoard)
    {
        bool isBoardFilled = true;
        foreach (char elem in gameBoard)
        {
            if (elem == '-') { isBoardFilled = false; break; }
        }
        if (isBoardFilled) return 3;

        // 264 == X+X+X

        //237 == O+O+O

        // --Player 1 : WIN
        if (rowCheck(gameBoard, 264) || colCheck(gameBoard,264) || diagonalCheck(gameBoard,264)) { return 1; }

        // --Player 2 : WIN
        else if (rowCheck(gameBoard, 237) || colCheck(gameBoard ,237) || diagonalCheck(gameBoard ,237)) { return 2; }

        return 4;
    }

  


}